package com.example.s04acalculadora;

public class GloboCalc {

    public GloboCalc()
    {

    }
    public String Calc()
    {
        return "";
    }
    public String setElement(String Element)
    {
        return "resolver";
    }
}
