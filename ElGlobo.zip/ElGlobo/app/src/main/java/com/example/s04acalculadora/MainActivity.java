package com.example.s04acalculadora;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private TextView Display;
    GloboCalc Globo=new GloboCalc();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // user code
        Display=(TextView) findViewById(R.id.Display);
        Display.setText("");
    }

    public void Coloca(View button)
    {
      Button B=(Button) button;
      Display.setText(B.getText());
      Globo.setElement(B.getText().toString());
    }
}